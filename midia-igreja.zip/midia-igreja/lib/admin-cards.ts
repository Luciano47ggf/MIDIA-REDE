import type { AdminAlbumCardData } from "@/components/admin/album-card";
import { appUrl } from "@/lib/env";
import { coverUrl } from "@/lib/media";
import type { AlbumOverview } from "@/types";

export function toAdminCard(a: AlbumOverview): AdminAlbumCardData {
  return {
    id: a.id,
    title: a.title,
    slug: a.slug,
    eventDate: a.event_date,
    status: a.status,
    photos: a.photo_count,
    videos: a.video_count,
    coverUrl: coverUrl(a.cover_thumb_key),
    publicUrl: `${appUrl()}/a/${a.slug}`,
  };
}
